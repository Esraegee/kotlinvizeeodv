﻿class YemekTarifi {
  var yemekAdi = ""
  var malzemeler = ""
  var yapilis = ""
}

fun main() {
  val tarif = YemekTarifi()

 println("Lütfen tarifini vermek istediğiniz yemeğin adını giriniz :")
 tarif.yemekAdi = readLine()!!
 println("Şimdi malzemeleri tek satırda giriniz :")
 tarif.malzemeler = readLine()!!
 println("Nasıl yapılıyor? : ")
 tarif.yapilis = readLine()!!

